from flask import request,render_template,redirect,url_for,session,Flask
import os,json
from func.config import host,username,password,port
import hashlib
from functools import wraps
import time
import random
import sqlite3
from threading import Thread
from func.server import main as fuckNAT
app=Flask(__name__,template_folder='static')
app.secret_key='1996-05-16'
configPath = os.path.join(os.getcwd(),'config.json')
configPort = 10000
if not os.path.isfile(configPath):
    with open(configPath,'w') as f:
        f.write(json.dumps({"http":{"to_master":"0.0.0.0:10001","customer":"0.0.0.0:800","host":[{"domain":host}]},"tcp":[]}))
else:
    with open(configPath,'r') as f:
        try:
            configPort = int(json.loads(f.read()).get('tcp')[-1].get('master').replace('0.0.0.0:',''))+1
        except:
            pass
def creadPort():
    try:
        global configPort
        if configPort>=20000:
            return [False,'连接过多！']
        md5_obj = hashlib.md5()
        md5_obj.update(str(random.random()).encode())
        md5 = md5_obj.hexdigest().lower()[10:]
        willWriteData = ''
        with open(configPath,'r') as f:
            willWriteDataList = json.loads(f.read()).get('tcp')
            willWriteDataList.append({"master":"0.0.0.0:"+str(configPort),"customer":"0.0.0.0:"+str(configPort+10000),"secretkey":md5})
            willWriteData = json.dumps({"http":{"to_master":"0.0.0.0:10001","customer":"0.0.0.0:800","host":[{"domain":host}]},"tcp":willWriteDataList})
        configPort+=1
        with open(configPath,'w') as f:
            f.write(willWriteData)
    except Exception as e:
        return [False,e]
    else:
        return [True,(configPort-1,configPort+10000-1,md5)]
def cklogin(**kw):
    def ck(func):
        @wraps(func)
        def _ck(*args, **kwargs):
            pwd=session.get('password')
            name=session.get('username')
            if (name == username) and (pwd == password):
                return func(*args, **kwargs)
            else:
                return redirect(url_for('login'))
        return _ck
    return ck
#登陆
@app.route("/login",methods=["POST","GET"])
def login():
    if request.method == 'POST':
        if ( request.values.get('username') == username ) and ( request.values.get('password') == password ):
            session['password']=request.form['password']
            session['username']=request.form['username']
            session['secectList'] = '[]'
            return redirect('/')
        else:
            return render_template('login.html',text = '账号或密码错误!')
    else:
        return render_template('login.html',text = '')
@app.route('/CreatDriver',methods=['POST'])
def CreatDriver():
    driverID = request.values.get('driverID')
    sqlResult = sql.selectDriverInfo(driverID)
    if sqlResult:
        return json.dumps({'resultCode':0,'result':sqlResult})
    creatResult = creadPort()
    if not creatResult[0]:
        return json.dumps({'resultCode':1})
    else:
        sql.insertInfo(driverID,[driverID,creatResult[1][1],creatResult[1][2],time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))])
        return json.dumps({'resultCode':0,'result':creatResult[1]})
@app.route('/',methods=['GET','POST'])
@cklogin()
def Driver():
    if request.method == 'GET':
        return render_template('driver.html',host=host)
    else:
        pool = sql.selectInfo()
        if pool[0]:
            return json.dumps({'result':pool[1]})

@app.route('/deleteDriver',methods=['POST'])
@cklogin()
def deleteDriver():
    sql.deleteInfo(request.values.get('IDS'))
    return 'success'
@app.route('/changeDriverNOTE',methods=['POST'])
@cklogin()
def changeDriverNOTE():
    IDS=request.values.get('IDS')
    NOTE = request.values.get('NOTE')
    sql.changeNote(IDS,NOTE)
    return 'success'


class sqlClass(object):
    def __init__(self):
        logDB = 'pool.db'
        sqlpath=(os.path.dirname(os.path.realpath(__file__)))
        if logDB in os.listdir(sqlpath):
            self.con = sqlite3.connect(os.path.join(sqlpath,logDB),check_same_thread = False)
        else:
            self.con = sqlite3.connect(os.path.join(sqlpath,logDB),check_same_thread = False)
            self.con.execute('''CREATE TABLE INFO 
                (
                IDS     TEXT,
                INFO    TEXT,
                NOTE    TEXT
                );''')
    def insertInfo(self,IDS,info):
        self.con.execute("INSERT INTO INFO (IDS,INFO,NOTE) VALUES (?,?,?)",(IDS,json.dumps(info),'点击添加备注...'))
        self.con.commit()
    def selectInfo(self):
        try:
            resultData = self.con.execute('SELECT * FROM INFO').fetchall()
            result = [True,resultData]
        except Exception as e:
            result = [False,str(e)]
        return result
    def selectDriverInfo(self,IDS):
        resultData = self.con.execute('SELECT * FROM INFO WHERE IDS = ?',(IDS,)).fetchall()
        if len(resultData) >= 1:
            data = json.loads(resultData[0][1])
            data[0] = data[1]-10000
            return data
        else:
            return None
    def deleteInfo(self,IDS):
        self.con.execute('DELETE FROM INFO WHERE IDS = ?',(IDS,))
        self.con.commit()
    def changeNote(self,IDS,NOTE):
        self.con.execute('UPDATE INFO SET NOTE=? WHERE IDS=?',(NOTE,IDS))
        self.con.commit()
sql = sqlClass()
if __name__ == '__main__':
    t=Thread(target=fuckNAT)
    t.setDaemon(True)
    t.start()
    app.run(host='0.0.0.0',port=port,debug = False)